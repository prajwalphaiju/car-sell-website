// Function to validate the add car form
function validateAddCarForm() {
  // Retrieve form field values
  var make = document.getElementById('make').value;
  var model = document.getElementById('model').value;
  var year = document.getElementById('year').value;
  var mileage = document.getElementById('mileage').value;
  var location = document.getElementById('location').value;
  var price = document.getElementById('price').value;

  // Check if any field is empty
  if (make === '' || model === '' || year === '' || mileage === '' || location === '' || price === '') {
    alert("Please fill in all fields!"); // Display an alert message
    return false; // Prevent form submission
  }

  return true; // Allow form submission
}

// Add an event listener to the form submit event
document.getElementById('addCarForm').addEventListener('submit', function(event) {
  // If form validation fails, prevent form submission
  if (!validateAddCarForm()) {
    event.preventDefault(); // Prevent default form submission behavior
  }
});

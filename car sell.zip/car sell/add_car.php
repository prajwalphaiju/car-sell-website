<?php
session_start();

$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'car_sell';

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.html");
    exit();
}

// Get the logged-in seller's ID
$seller_username = $_SESSION['username'];
$sql = "SELECT id FROM seller WHERE username = '$seller_username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $seller_id = $row['id'];
} else {
    die("User not found.");
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $make = $_POST['make'];
    $model = $_POST['model'];
    $year = $_POST['year'];
    $mileage = $_POST['mileage'];
    $location = $_POST['location'];
    $price = $_POST['price'];

    // Handle file upload
    if (isset($_FILES['car_image']) && $_FILES['car_image']['error'] == 0) {
        $target_dir = "uploads/";
        // Ensure the upload directory exists and is writable
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0755, true);
        }
        $target_file = $target_dir . basename($_FILES['car_image']['name']);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        // Check if image file is an actual image or fake image
        $check = getimagesize($_FILES['car_image']['tmp_name']);
        if ($check === false) {
            header("Location: add_car.html?error=" . urlencode("File is not an image."));
            exit();
        }

        // Check file size
        if ($_FILES['car_image']['size'] > 5000000) { // 5MB limit
            header("Location: add_car.html?error=" . urlencode("Sorry, your file is too large."));
            exit();
        }

        // Allow certain file formats
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            header("Location: add_car.html?error=" . urlencode("Sorry, only JPG, JPEG, PNG & GIF files are allowed."));
            exit();
        }

        // Attempt to move the uploaded file to the server
        if (!move_uploaded_file($_FILES['car_image']['tmp_name'], $target_file)) {
            header("Location: add_car.html?error=" . urlencode("Sorry, there was an error uploading your file."));
            exit();
        }
    } else {
        $target_file = null; // No file uploaded
    }

    // Insert into database
    $sql = "INSERT INTO car (seller_id, make, model, year, mileage, location, price, image_path) 
            VALUES ('$seller_id', '$make', '$model', '$year', '$mileage', '$location', '$price', '$target_file')";

    if ($conn->query($sql) === TRUE) {
        header("Location: add_car.html?success=1");
    } else {
        header("Location: add_car.html?error=" . urlencode($conn->error));
    }

    $conn->close();
    exit();
}
?>

<?php
session_start();

$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'car_sell';

// create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    // Retrieve user data from database
    $sql = "SELECT * FROM seller WHERE username = '$user'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($pass, $row['password'])) {
            // Password is correct, start a session
            $_SESSION['username'] = $user;
            header("Location: add_car.html");
        } else {
            // Password is incorrect
            header("Location: login.html?error=" . urlencode("Invalid username or password."));
        }
    } else {
        // Username does not exist
        header("Location: login.html?error=" . urlencode("Invalid username or password."));
    }

    $conn->close();
    exit();
}
?>

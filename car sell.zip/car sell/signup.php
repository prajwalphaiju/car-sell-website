<?php

$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'car_sell';

// create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize a variable to hold the success message
$successMessage = "";

// Form submission handling
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $user = $_POST['username'];
    $email = $_POST['email'];                                                                              
    $pass = $_POST['password'];

    // Hash the password
    $hashed_password = password_hash($pass, PASSWORD_DEFAULT);

    // Insert into database
    $sql = "INSERT INTO seller (name, address, phone, username, email, password) VALUES ('$name', '$address', '$phone', '$user', '$email', '$hashed_password')";

    if ($conn->query($sql) === TRUE) {
        header("Location: seller_registration.html?success=1");
    } else {
        header("Location: seller_registration.html?error=" . urlencode($conn->error));
    }

    $conn->close();
    exit();
}
?>

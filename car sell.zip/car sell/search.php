<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car_sell";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$model = $_GET['model'] ?? '';
$location = $_GET['location'] ?? '';

$sql = "SELECT * FROM car WHERE 1=1";

if ($model) {
    $sql .= " AND model LIKE '%$model%'";
}

if ($location) {
    $sql .= " AND location LIKE '%$location%'";
}

$result = $conn->query($sql);

$cars = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $cars[] = $row;
    }
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($cars);
?>

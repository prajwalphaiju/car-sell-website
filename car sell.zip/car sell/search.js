document.addEventListener("DOMContentLoaded", () => {
    const searchForm = document.getElementById('search-form');
    const showAllButton = document.getElementById('show-all');
    const resultsDiv = document.getElementById('results');

    searchForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const model = document.getElementById('model').value;
        const location = document.getElementById('location').value;
        const response = await fetch(`search.php?model=${model}&location=${location}`);
        const cars = await response.json();
        displayCars(cars);
    });

    showAllButton.addEventListener('click', async () => {
        const response = await fetch('search.php');
        const cars = await response.json();
        displayCars(cars);
    });

    function displayCars(cars) {
        resultsDiv.innerHTML = '';
        if (cars.length === 0) {
            resultsDiv.innerHTML = '<p>No cars found</p>';
            return;
        }
        cars.forEach(car => {
            const carDiv = document.createElement('div');
            carDiv.className = 'car-item';
            carDiv.innerHTML = `
                <img src="${car.image_path}" alt="${car.model}">
                <h3>${car.model}</h3>
                <p>Price: ${car.price}</p>
                <p>Location: ${car.location}</p>
                <p>Year: ${car.year}</p>
                <p>Mileage: ${car.mileage}</p>
            `;
            resultsDiv.appendChild(carDiv);
        });
    }
});

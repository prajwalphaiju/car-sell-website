// Function to validate the login form
function validateLoginForm() {
    // Retrieve username and password from the form
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
  
    // Validate username
    var usernamePattern = /^[a-zA-Z]+$/;
    if (!username.match(usernamePattern)) {
      alert("Username should only contain alphabets and cannot be empty!"); // Display an alert message
      return false; // Prevent form submission
    }
  
    // Validate password
    var passwordPattern = /^(?=.*[a-zA-Z])(?=.*\d)(?=.*[@#$?])[A-Za-z\d@#$?]{6,10}$/;
    if (!password.match(passwordPattern)) {
      alert("Password should be between 6 and 10 characters long and contain at least one alphabet, one number, and one of the following special characters: '@', '#', '$', '?'"); // Display an alert message
      return false; // Prevent form submission
    }
  
    return true; // Allow form submission if validation passes
  }
  
  // Add an event listener to the form submit event
  document.getElementById('loginForm').addEventListener('submit', function(event) {
    // If form validation fails, prevent form submission
    if (!validateLoginForm()) {
      event.preventDefault(); // Prevent default form submission behavior
    }
  });
  